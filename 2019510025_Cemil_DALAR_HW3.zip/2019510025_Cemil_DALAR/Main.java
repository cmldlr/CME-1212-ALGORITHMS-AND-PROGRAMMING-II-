import java.util.Random;

public class Main {
    public static Random rand=new Random();
    public static Queue randomnumbers(Queue bag1){
        Queue player=new Queue(1000);
        Queue temp_bag1=new Queue(50);
        int x=bag1.size();
        for (int i = 0; i < x; i++) {
            temp_bag1.enqueue(bag1.peek());
            bag1.enqueue(bag1.dequeue());
        }
        int count=0;
        for (int i = 0; i <100; i++) {
            int a=rand.nextInt(17)+1;
            int y= bag1.size();
            for (int j = 0; j <y; j++) {
                String str=String.valueOf(bag1.peek());
                int b=Integer.parseInt(str);
                if(a==b){
                    player.enqueue(bag1.peek());
                    count++;
                    bag1.dequeue();
                }
                else{
                    bag1.enqueue(bag1.dequeue());
                }
            }
            if(count==7){
                break;
            }
        }
        for (int i = 0; i < x-count; i++) {
           bag1.dequeue();
        }
        for (int i = 0; i < x; i++) {
            bag1.enqueue(temp_bag1.dequeue());
        }
        return  player;
    }
    public static void playgame(Queue bag1,Queue player1,Queue player2){
        Queue bag2=new Queue(1000);
        int x=bag1.size();
        int player1s_money=0;
        int player2s_money=0;
        boolean flag=true;
        boolean onlyonce=true;
        for (int i = 0; i <x; i++) {
           int size=bag1.size();
           int a=rand.nextInt(size)+1;
           int count=1;
           int b=0;
           for (int j = 0; j < size; j++) {
               if(count==a){
                   String str=String.valueOf(bag1.peek());
                   b=Integer.parseInt(str);
                   bag2.enqueue(bag1.dequeue());
               }
               else{
                   bag1.enqueue(bag1.dequeue());
               }
               count++;
           }

            System.out.println("Randomly selected number: "+b);
           int size1=player1.size();
           for (int j = 0; j < size1;j++) {
               String str=String.valueOf(player1.peek());
               int c=Integer.parseInt(str);
               if(b==c){
                   player1.dequeue();
               }
               else{
                   player1.enqueue(player1.dequeue());
               }
           }
           int size2= player2.size();
           for (int j = 0; j <size2; j++) {
               String str=String.valueOf(player2.peek());
               int c=Integer.parseInt(str);
               if(b==c){
                   player2.dequeue();
               }
               else{
                   player2.enqueue(player2.dequeue());
               }
           }
           System.out.println(" ");
           printsteps(bag1,bag2,player1,player2);
           if(player1.size()==3 && onlyonce && player2.size()!=3){
               System.out.println("Player1 gets $10 (Birinci Çinko)");
               onlyonce=false;
               player1s_money=player1s_money+10;
           }
           if(player2.size()==3 && onlyonce && player1.size()!=3){
               System.out.println("Player2 gets $10 (Birinci Çinko)");
               onlyonce=false;
               player2s_money=player2s_money+10;
           }
           if(player1.size()==3 && onlyonce && player2.size()==3){
               System.out.println("Player1 gets $10 (Birinci Çinko)");
               System.out.println("Player2 gets $10 (Birinci Çinko)");
               onlyonce=false;
               player1s_money=player1s_money+10;
               player2s_money=player2s_money+10;
           }

           if(player1.size()==0 && player2.size()!=0){
                player1s_money=player1s_money+30;
               flag=false;
           }
           if(player2.size()==0 && player1.size()!=0){
               player2s_money=player2s_money+30;
               flag=false;
           }
           if(player1.size()==0 && player2.size()==0){
               player1s_money=player1s_money+30;
               player2s_money=player2s_money+30;
               flag=false;

           }
           if(!flag){
               break;
           }
        }
        if(player1.size()==0 && player2.size()!=0){
            System.out.println(" ");
            System.out.println("Player1 is the winner !!!");

        }
        else if(player2.size()==0 && player1.size()!=0){
            System.out.println(" ");
            System.out.println("Player2 is the winner !!!");

        }
        else if(player2.size()==0 && player1.size()==0 && player1s_money==player2s_money){
            System.out.println(" ");
            System.out.println("Two players tie");

        }
        else if(player2.size()==0 && player1.size()==0 && player1s_money>player2s_money){
            System.out.println(" ");
            System.out.println("Player1 is the winner !!!");
        }
        else if(player2.size()==0 && player1.size()==0 && player1s_money<player2s_money){
            System.out.println(" ");
            System.out.println("Player2 is the winner !!!");
        }
        System.out.println("Player1 gets "+player1s_money+"$");
        System.out.println("Player2 gets "+player2s_money+"$");
    }
    public static void printsteps(Queue bag1,Queue bag2,Queue player1,Queue player2){
        int x=player1.size();
        System.out.print("player1: ");
        for (int i = 0; i < x; i++) {
            System.out.printf("%s",player1.peek()+" ");
            player1.enqueue(player1.dequeue());
        }
        System.out.print(" ");
        int z= bag1.size();
        System.out.print("                                          bag1:");
        System.out.print(" ");
        for (int i = 0; i < z; i++) {
            System.out.printf("%s ",bag1.peek()+" ");
            bag1.enqueue(bag1.dequeue());
        }
        System.out.println(" ");
        System.out.print("player2:");
        System.out.print(" ");
        int y= player2.size();
        for (int i = 0; i < y; i++) {
            System.out.printf("%s",player2.peek()+" ");
            player2.enqueue(player2.dequeue());
        }
        System.out.print(" ");
        System.out.print("                                          bag2:");
        System.out.print(" ");
        int w= bag2.size();
        for (int i = 0; i < w;i++) {
            System.out.printf("%s",bag2.peek()+" ");
            bag2.enqueue(bag2.dequeue());
        }
        System.out.println(" ");
    }
    public static void main(String[] args) {
        Queue bag1=new Queue(1000);
        Queue bag2=new Queue(1000);
        Queue player1=new Queue(1000);
        Queue player2=new Queue(1000);
        for (int i = 1; i <18; i++) {
            bag1.enqueue(i);
        }
        player1=randomnumbers(bag1);
        player2=randomnumbers(bag1);
        System.out.println(" ");
        printsteps(bag1,bag2,player1,player2);
        playgame(bag1,player1,player2);
    }
}