

public class Team {
    private String team_name;
    private Date  foundationyear;
    private int  numberofcups;
    private String color1;
    private String color2;
    private int team_id;
    private Player [] team_players=new Player[30];
    private  int team_players_count=0;
    private Coach coach;
    private Company company;
    private int point=0;


    public Team(String team_name,Date foundationyear, int numberofcups, String color,int team_id){

        this.team_name = team_name;
        this.foundationyear = foundationyear;
        this.numberofcups = numberofcups;
        String[] colors=color.split(" ");
        this.color1 = colors[0];
        this.color2 = colors[1];
        this.team_id=team_id;

    }
    public Team(){

    }
    public Team(String team_name){
        this.team_name=team_name;

    }

    public Player[] getTeam_players() {
        return team_players;
    }

    public void setTeam_players(Player[] team_players) {
        this.team_players = team_players;
    }
    public void addplayers(Player player){

        team_players[team_players_count]= player;
        team_players_count++;
        if(team_players_count>30){
            System.out.println("A team can have a maximum of 30 players.");

        }

    }
    public void addCoach(Coach coach){
       this.coach=coach;
    }
    public void addCompany(Company company){
        this.company=company;
    }
    public void addPoint(int point){

        this.point=this.point+point;

    }
    public void list(){
        System.out.println(this.team_id+"."+"Team Name="+this.team_name+",Team Coach="+this.coach.getName());
    }


    public void setTeam_name(String team_name) {
        this.team_name = team_name;
    }

    public String getTeam_name() {
        return team_name;
    }

    public void setFoundationyear(Date year) {
        this.foundationyear= foundationyear;
    }

    public Date getFoundationyear() {
        return foundationyear;
    }

    public void setNumberofcups(int numberofcups) {
        this.numberofcups = numberofcups;
    }

    public int getNumberofcups() {
        return numberofcups;
    }

    public void setColor1(String color1) {
        this.color1 = color1;
    }

    public String getColor1() {
        return color1;
    }

    public void setColor2(String color2) {
        this.color2 = color2;
    }

    public String getColor2() {
        return color2;
    }

    public int getTeam_id() {
        return team_id;
    }

    public void setTeam_id(int team_id) {
        this.team_id = team_id;
    }

    public Coach getCoach() {
        return coach;
    }

    public void setCoach(Coach coach) {
        this.coach = coach;
    }

    public Company getCompany() {
        return company;
    }

    public void setCompany(Company company) {
        this.company = company;
    }

    public int getPoint() {
        return point;
    }

    public void setPoint(int point) {
        this.point = point;
    }

    @Override
    public String toString() {
        return "Team{" +
                "team_name='" + team_name + '\'' +
                ", foundationyear=" + foundationyear +
                ", numberofcups=" + numberofcups +
                ", color1='" + color1 + '\'' +
                ", color2='" + color2 + '\'' +
                ", team_id=" + team_id +
                '}';
    }
}
