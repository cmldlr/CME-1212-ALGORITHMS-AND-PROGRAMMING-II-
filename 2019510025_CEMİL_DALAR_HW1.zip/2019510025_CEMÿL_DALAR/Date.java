

public class Date {
    private int day;
    private int month;
    private int year;

    public Date(int day,int month,int year){

        if (year<0) {
            System.out.println("!!!ERROR Year cannot be negative");
        }
        if(month==2){

            if(year%4==0){

                if(day>29 || day<1){
                    System.out.println("!!!ERROR This date is wrong.");
                    System.out.println("!!!ERROR  In "+ year +" year the month of the february cannot be more than 29 days or less than 1 day.");
                }
                else{

                    this.day=day;
                    this.month=month;
                    this.year=year;
                }
            }
            else{

                if(day>28 || day<1){
                    System.out.println("!!!ERROR This date is wrong.");
                    System.out.println("!!!ERROR  In "+ year +" year the month of the february cannot be more than 28 days or less than 1 day.");
                }
                else{

                    this.day=day;
                    this.month=month;
                    this.year=year;
                }



            }
        }
        else{

            if(month==1 || month==3 ||month==5 ||month==7 ||month==8 ||month==10 ||month==12 ){

                if(day>31 || day<1){
                    System.out.println("!!!ERROR This date is wrong.");
                    System.out.println("!!!ERROR Day cannot be less than 1 and greater than 31.");
                }
                else{

                    this.day=day;
                    this.month=month;
                    this.year=year;
                }
            }
            else if(month==4 || month==6 ||month==9 ||month==11 ){

                if(day>30 || day<1){
                    System.out.println("!!!ERROR This date is wrong.");
                    System.out.println("!!!ERROR Day cannot be less than 1 and greater than 30.");
                }
                else{

                    this.day=day;
                    this.month=month;
                    this.year=year;
                }

            }
        }





    }
    public Date(int year){
        if (year<0) {
            System.out.println("!!!ERROR Year cannot be negative");
        }
        else{
            this.year = year;
        }

    }
    public void setDay(int day) {
        if (day<=31 && day>=1) {
            this.day = day;
        }
        else{
            System.out.println("!!!ERROR Day cannot be less than 1 and greater than 31.");
        }

    }

    public int getDay() {
        return day;
    }

    public void setMonth(int month) {
        if (month<=12 &&  month>=1) {
            this.month=month;
        }
        else{
            System.out.println("!!!ERROR Month cannot be less than 1 and greater than 12.");
        }

    }

    public int getMonth() {
        return month;
    }

    public void setYear(int year) {
        if (year<0) {
            System.out.println("!!!ERROR Year cannot be negative");
        }
        else{
             this.year = year;
        }
    }

    public int getYear() {
        return year;
    }

    @Override
    public String toString() {
        return "Date{" +
                "day=" + day +
                ", month=" + month +
                ", year=" + year +
                '}';
    }
}
