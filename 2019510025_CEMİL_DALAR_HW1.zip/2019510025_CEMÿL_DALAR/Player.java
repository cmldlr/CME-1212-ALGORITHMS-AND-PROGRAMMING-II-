

public class Player {

    private int license_number;
    private String namesurname;
    private Date birthdate;
    private String nationality;
    private Adress adress;
    private Phone phonenumber;
    private Date startdate;
    private Date enddate;
    private int salary;
    private String positionrole;
    private int  player_id;

    public Player(int license_number,String namesurname,Date birthdate,String nationality,Adress adress,Phone phonenumber,Date startdate,Date enddate,int salary,String positionrole,int player_id){
        this.license_number=license_number;
        this.namesurname= namesurname;
        this.birthdate=birthdate;
        this.nationality=nationality;
        this.adress=adress;
        this.phonenumber = phonenumber;
        this.salary=salary;
        this.positionrole=positionrole;
        this.player_id=player_id;

        if(enddate.getYear()<startdate.getYear()){
            System.out.println("!!!ERROR End date cannot be smaller than start date");
        }
        else{
            if(enddate.getYear()==startdate.getYear()){
                if(enddate.getMonth()<startdate.getMonth()){
                    System.out.println("!!!ERROR End date cannot be smaller than start date");
                }
                else{
                    if(enddate.getMonth()==startdate.getMonth()){
                        if(enddate.getDay()<startdate.getDay()){
                            System.out.println("!!!ERROR End date cannot be smaller than start date");
                        }
                        else{
                            this.startdate = startdate;
                            this.enddate = enddate;
                        }
                    }
                    else{
                        this.startdate = startdate;
                        this.enddate = enddate;
                    }
                }
            }
            else{
                this.startdate = startdate;
                this.enddate = enddate;
            }

        }
        if (salary<0){
            System.out.println("!!!ERROR Salary cannot be negative");
        }
        else{
            this.salary = salary;
        }


    }

    public int getLicense_number() {
        return license_number;
    }

    public void setLicense_number(int license_number) {
        this.license_number = license_number;
    }

    public String getNamesurname() {
        return namesurname;
    }

    public void setNamesurname(String namesurname) {
        this.namesurname = namesurname;
    }

    public Date getBirthdate() {
        return birthdate;
    }

    public void setBirthdate(Date birthdate) {
        this.birthdate = birthdate;
    }

    public String getNationality() {
        return nationality;
    }

    public void setNationality(String nationality) {
        this.nationality = nationality;
    }

    public Adress getAdress() {
        return adress;
    }

    public void setAdress(Adress adress) {
        this.adress = adress;
    }

    public Phone getPhonenumber() {
        return phonenumber;
    }

    public void setPhonenumber(Phone phonenumber) {
        this.phonenumber = phonenumber;
    }

    public Date getStartdate() {
        return startdate;
    }

    public void setStartdate(Date startdate) {
        this.startdate = startdate;
    }

    public Date getEnddate() {
        return enddate;
    }

    public void setEnddate(Date enddate) {
        this.enddate = enddate;
    }

    public int getSalary() {
        return salary;
    }

    public void setSalary(int salary) {
        this.salary = salary;
    }

    public String getPositionrole() {
        return positionrole;
    }

    public void setPositionrole(String positionrole) {
        this.positionrole = positionrole;
    }

    public int getPlayer_id() {
        return player_id;
    }

    public void setPlayer_id(int player_id) {
        this.player_id = player_id;
    }

    @Override
    public String toString() {
        return "Player{" +
                "license_number=" + license_number +
                ", namesurname='" + namesurname + '\'' +
                ", birthdate=" + birthdate.toString()+
                ", nationality='" + nationality + '\'' +
                ", adress=" + adress.toString()+
                ", phonenumber=" + phonenumber.toString()+
                ", startdate=" + startdate.toString()+
                ", enddate=" + enddate.toString()+
                ", salary=" + salary +
                ", positionrole='" + positionrole + '\'' +
                ", player_id=" + player_id +
                '}';
    }
}
