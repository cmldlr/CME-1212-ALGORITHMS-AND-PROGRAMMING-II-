



import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;


public class Main {

    //The inner class is below the referee class.
    public static int  addteam_count,addcoach_count,addplayer_count,addstadium_count,addreferee_count,addcompany_count,addmatch_count, deleteplayer_count;
    public static Team [] teams=new Team[21];
    public static Stadium [] stadiums=new Stadium[60];
    public static Referee [] referees=new Referee[20];
    public static Match[] matches=new Match[30];
    //adding team
    public static void addTeam(String [] parts){
        Date foundationyear=new Date(Integer.parseInt(parts[2]));
        teams[addteam_count]=new Team(parts[1],foundationyear,Integer.parseInt(parts[3]), parts[4],addteam_count+1);
        addteam_count++;
    }
    //adding players to teams
    public static void addPlayer(String [] parts){
        Date birthdate=new Date(Integer.parseInt(parts[3]),Integer.parseInt(parts[4]),Integer.parseInt(parts[5]));
        Adress adress1=new Adress(parts[7],parts[8],parts[9],parts[10]);
        Phone phonenumber1=new Phone(Integer.parseInt(parts[11]),Integer.parseInt(parts[12]),Integer.parseInt(parts[13]));
        Date startdate1=new Date(Integer.parseInt(parts[15]),Integer.parseInt(parts[16]),Integer.parseInt(parts[17]));
        Date enddate1=new Date(Integer.parseInt(parts[18]),Integer.parseInt(parts[19]),Integer.parseInt(parts[20]));
        Player player=new Player(Integer.parseInt(parts[1]),parts[2],birthdate,parts[6],adress1,phonenumber1,startdate1,enddate1,Integer.parseInt(parts[21]),parts[22],addplayer_count+1);
        for (int i = 0; i <teams.length; i++) {
            if(teams[i]!=null && teams[i].getTeam_name().equalsIgnoreCase(parts[14])){
                teams[i].addplayers(player);



            }
        }


        addplayer_count++;

    }
    //adding coach to teams
    public static void addCoach(String [] parts){
        Adress adress=new Adress(parts[2],parts[3],parts[4],parts[5]);
        Phone phonenumber=new Phone(Integer.parseInt(parts[6]),Integer.parseInt(parts[7]),Integer.parseInt(parts[8]));
        Date startdate=new Date(Integer.parseInt(parts[10]),Integer.parseInt(parts[11]),Integer.parseInt(parts[12]));
        Date enddate=new Date(Integer.parseInt(parts[13]),Integer.parseInt(parts[14]),Integer.parseInt(parts[15]));
        Coach coach=new Coach(parts[1],adress,phonenumber,startdate,enddate,Integer.parseInt(parts[16]),addcoach_count+1);
        for (int i = 0; i <teams.length; i++) {
            if(teams[i]!=null && teams[i].getTeam_name().equalsIgnoreCase(parts[9])){
                teams[i].addCoach(coach);


            }


        }
        addcoach_count++;
    }
    //adding stadiums
    public static void addStadium(String [] parts){
        stadiums[addstadium_count]=new Stadium(parts[1],parts[2],Integer.parseInt(parts[3]),Boolean.parseBoolean(parts[4]),parts[5],addstadium_count+1);
        addstadium_count++;

    }
    //adding stadiums
    public static  void addReferee(String [] parts){
        Adress adress2=new Adress(parts[2],parts[3],parts[4],parts[5]);
        Phone phonenumber2=new Phone(Integer.parseInt(parts[6]),Integer.parseInt(parts[7]),Integer.parseInt(parts[8]));
        referees[addreferee_count]=new Referee(parts[1],adress2,phonenumber2,Integer.parseInt(parts[9]),addreferee_count+1);
        addreferee_count++;
    }
    //adding sponsor companies
    public static void addCompany(String[] parts){
        Adress adress=new Adress(parts[2],parts[3],parts[4],parts[5]);
        Phone phonenumber=new Phone(Integer.parseInt(parts[6]),Integer.parseInt(parts[7]),Integer.parseInt(parts[8]));

        Company company=new Company(parts[1],adress,phonenumber,addcompany_count+1);
        for (int i = 0; i <teams.length; i++) {
            if(teams[i]!=null && teams[i].getTeam_name().equalsIgnoreCase(parts[9])){
                teams[i].addCompany(company);

            }
        }
        addcompany_count++;

    }
    //delete players given license numbers
    public static void deletePlayer(String [] parts){
        for (int i = 0; i <teams.length; i++) {
            if(teams[i]!=null){
                for (int j = 0; j <teams[i].getTeam_players().length; j++) {
                    if(teams[i].getTeam_players()[j]!=null && teams[i].getTeam_players()[j].getLicense_number()==Integer.parseInt(parts[1])){

                        for(int k=i+1;k<addplayer_count;k++) {

                            teams[i].getTeam_players()[k - 1] =teams[i].getTeam_players()[k];


                        }
                         addplayer_count=addplayer_count-1;


                    }
                }
            }

        }

    }
    //adding matches
    public static  void addMatch(String [] parts){
        Team home_team=new Team();
        Team away_team=new Team();
        int hometeam_goals=Integer.parseInt(parts[2]);
        int awayteam_goals=Integer.parseInt(parts[4]);
        Referee referee1=new Referee();
        Referee referee2=new Referee();
        Referee referee3=new Referee();
        Stadium stadium=new Stadium();
        int a=0,b=0,c=0,d=0,e=0,f=0;
        boolean flag1=true;
        boolean flag2=true;
        boolean flag3=true;
        boolean flag4=true;
        boolean flag5=true;
        boolean flag6=true;
        boolean flag7=true;
        for (int i = 0; i <addteam_count; i++) {

            if(teams[i]!=null && teams[i].getTeam_name().equalsIgnoreCase(parts[1])){

                home_team=teams[i];
                a=5;

                break;

            }
            a++;
            if(a==addteam_count){
                System.out.println("Error. No such home team found. Please check your input.");
                flag1=false;
            }

        }
        for (int i = 0; i <addteam_count; i++) {
            if(teams[i]!=null && teams[i].getTeam_name().equalsIgnoreCase(parts[3])){

                away_team=teams[i];
                b=5;

                break;

            }
            b++;
            if(b==addteam_count){
                System.out.println("Error. No such away team found. Please check your input.");
                flag2=false;
            }
        }
        for (int i = 0; i <addreferee_count; i++) {
            if(referees[i]!=null && referees[i].getReferee_id()==Integer.parseInt(parts[5])){
                referee1=referees[i];
                c=5;

            }
            else if(referees[i]!=null && referees[i].getReferee_id()==Integer.parseInt(parts[6])){
                referee2=referees[i];
                d=5;

            }
            else if(referees[i]!=null && referees[i].getReferee_id()==Integer.parseInt(parts[7])){
                referee3=referees[i];
                e=5;

            }
            c++;
            d++;
            e++;
            if(c==addreferee_count){
                System.out.println("Error. No such 1st referee id found. Please check your input.");
                flag3=false;
            }
            if(d==addreferee_count){
                System.out.println("Error. No such 2nd referee id found. Please check your input.");
                flag4=false;
            }
            if(e==addreferee_count){
                System.out.println("Error. No such 3rd referee id found. Please check your input.");
                flag5=false;
            }
        }
        for (int i = 0; i <addstadium_count; i++) {
            if(stadiums[i]!=null && stadiums[i].getStatidum_id()==Integer.parseInt(parts[8])){
                stadium=stadiums[i];
                f=5;

            }
            f++;
            if(f==addstadium_count){
                System.out.println("Error. There is no stadium with such a stadium id. Please check your input.");
                flag6=false;
            }



        }
        if(referee1.getReferee_id()==referee2.getReferee_id() ||referee1.getReferee_id()==referee3.getReferee_id()||referee2.getReferee_id()==referee3.getReferee_id()){
            System.out.println("ERROR 3 different referees lead a match.There is an error in the referee information. Please check your input.");
            flag7=false;
        }


        int x=home_team.getTeam_id()-1;
        int y=away_team.getTeam_id()-1;
        if(flag1==false||flag2==false||flag3==false||flag4==false||flag5==false||flag6==false||flag7==false){
            System.out.println("This match cannot be played.");

        }
        else if(flag1==true&& flag2==true &&  flag3==true && flag4==true && flag5==true && flag6==true&&flag7==true ){
            matches[addmatch_count]=new Match(home_team,hometeam_goals,away_team,awayteam_goals,referee1,referee2,referee3,stadium,addmatch_count+1);
            addmatch_count++;
            if(hometeam_goals>awayteam_goals){
                int point=3;
                teams[x].addPoint(point);
            }
            else if(hometeam_goals<awayteam_goals){
                int point=3;
                teams[y].addPoint(point);
            }
            else if(hometeam_goals==awayteam_goals){
                int point=1;
                teams[x].addPoint(point);
                teams[y].addPoint(point);
            }
        }

    }
    public static void listTeams(){
        System.out.println("A)List all teams");
        System.out.println("-----------------------------------");
        for (int i = 0; i <teams.length; i++) {
            if(teams[i]!=null){
               teams[i].list();
            }
        }
        System.out.println("-----------------------------------");
    }
    public static void listPlayers(){
        int count=1;
        System.out.println("B)List all players");
        System.out.println("-----------------------------------");
        for (int i = 0; i <teams.length; i++) {
            if(teams[i]!=null){
                for (int j = 0; j <teams[i].getTeam_players().length; j++) {
                    if(teams[i].getTeam_players()[j]!=null){
                        System.out.println(count+"."+"Player Name Surname= "+ teams[i].getTeam_players()[j].getNamesurname());
                        count++;
                    }

                }
            }
        }
        System.out.println("-----------------------------------");
    }
    public static void listCompanies(){
        int count=1;
        System.out.println("C) List all sponsor companies ");
        System.out.println("-----------------------------------");
        for (int i = 0; i <teams.length; i++) {
            if(teams[i]!=null){
                System.out.println(count+"."+"Company Name="+teams[i].getCompany().getName());
                count++;

            }


        }
        System.out.println("-----------------------------------");
    }
    public static void findscores(){
        System.out.println("Scores:");
        int a=teams[0].getPoint();
        for (int i = 0; i <teams.length; i++) {
            if(teams[i]!=null ){
                System.out.println( teams[i].getTeam_name() +" "+teams[i].getPoint());

            }
            if(teams[i]!=null&& teams[i].getPoint()>a){
                a=teams[i].getPoint();
            }

        }
        for (int i = 0; i <teams.length; i++) {
            if(teams[i]!=null && teams[i].getPoint()==a){
                System.out.println("WİNNER:"+ teams[i].getTeam_name());

            }
        }

    }
    public static void findthebiggeststadium(){
        System.out.println("-----------------------------------");
        int b=stadiums[0].getCapacity();
        for (int i = 0; i <stadiums.length; i++) {
            if(stadiums[i]!=null &&stadiums[i].getCapacity()>b) {
                b=stadiums[i].getCapacity();
            }

        }
        for (int i = 0; i <stadiums.length; i++) {
            if( stadiums[i]!=null && stadiums[i].getCapacity()==b){
                System.out.println("The biggest stadium:"+stadiums[i].getName());
            }
        }
        System.out.println("-----------------------------------");
    }
    public static void addraise(){
        for (int i = 0; i <referees.length; i++) {
            if(referees[i]!=null){
                referees[i].addRaise(10);

            }
        }
    }
    public static void listRefeeres(){
        int count=1;
        System.out.println( "List all sponsor  referees ");
        System.out.println("-----------------------------------");
        for (int i = 0; i <referees.length; i++) {
            if(referees[i]!=null){
                System.out.println(count+"."+"Referee name:"+referees[i].getName());
                count++;
            }
        }
        System.out.println("-----------------------------------");
    }
    public static void main(String[] args) throws IOException {

        BufferedReader br=new BufferedReader(new FileReader("D:\\input.txt"));
        String str;
        addteam_count=addcoach_count=addplayer_count=addstadium_count=addreferee_count=addcompany_count=addmatch_count= deleteplayer_count=0;

        while((str= br.readLine())!=null){
            String [] parts=str.split(";");

            switch (parts[0]){

                case "AddTeam":
                    addTeam(parts);
                    break;
                case "AddCoach":
                     addCoach(parts);
                    break;
                case "AddPlayer":
                    addPlayer(parts);
                    break;
                case "AddStadium":
                    addStadium(parts);
                    break;
                case "AddReferee":
                    addReferee(parts);
                    break;
                case "AddCompany":
                    addCompany(parts);
                    break;
                case "DeletePlayer":
                    deletePlayer(parts);
                    break;
                case "AddMatch":
                    addMatch(parts);
                    break;

            }


        }
        listTeams();
        listPlayers();
        listCompanies();
        findscores();
        findthebiggeststadium();
        addraise();
        listRefeeres();







    }
}
