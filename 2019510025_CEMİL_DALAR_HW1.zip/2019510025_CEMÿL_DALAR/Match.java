public class Match {
    private Team home_team;
    private int hometeam_goals;
    private Team away_team;
    private int awayteam_goals;
    private Referee referee1;
    private Referee referee2;
    private Referee referee3;
    private Stadium stadium;
    private int match_id;

    public Match(Team home_team,int hometeam_goals,Team away_team,int awayteam_goals,Referee referee1,Referee referee2,Referee referee3,Stadium stadium,int match_id) {
        this.home_team = home_team;
        if(hometeam_goals>=0 && awayteam_goals>=0){
            this.hometeam_goals=hometeam_goals;
            this.awayteam_goals=awayteam_goals;
        }
        else{
            System.out.println("Number of goals cannot be less than zero");
        }
        if(referee1==null || referee2==null || referee3==null){
            System.out.println("this match cannot be played");
        }
        this.away_team=away_team;
        this.awayteam_goals=awayteam_goals;
        this.referee1=referee1;
        this.referee2=referee2;
        this.referee3=referee3;
        this.stadium=stadium;
        this.match_id=match_id;
    }

    public Team getHome_team() {
        return home_team;
    }

    public void setHome_team(Team home_team) {
        this.home_team = home_team;
    }

    public int getHometeam_goals() {
        return hometeam_goals;
    }

    public void setHometeam_goals(int hometeam_goals) {
        this.hometeam_goals = hometeam_goals;
    }

    public Team getAway_team() {
        return away_team;
    }

    public void setAway_team(Team away_team) {
        this.away_team = away_team;
    }

    public int getAwayteam_goals() {
        return awayteam_goals;
    }

    public void setAwayteam_goals(int awayteam_goals) {
        this.awayteam_goals = awayteam_goals;
    }

    public Referee getReferee1() {
        return referee1;
    }

    public void setReferee1(Referee referee1) {
        this.referee1 = referee1;
    }

    public Referee getReferee2() {
        return referee2;
    }

    public void setReferee2(Referee referee2) {
        this.referee2 = referee2;
    }

    public Referee getReferee3() {
        return referee3;
    }

    public void setReferee3(Referee referee3) {
        this.referee3 = referee3;
    }

    public Stadium getStadium() {
        return stadium;
    }

    public void setStadium(Stadium stadium) {
        this.stadium = stadium;
    }

    public int getMatch_id() {
        return match_id;
    }

    public void setMatch_id(int match_id) {
        this.match_id = match_id;
    }

    @Override
    public String toString() {
        return "Match{" +
                "home_team=" + home_team.toString()+
                ", hometeam_goals=" + hometeam_goals +
                ", away_team=" + away_team.toString()+
                ", awayteam_goals=" + awayteam_goals +
                ", referee1=" + referee1.toString()+
                ", referee2=" + referee2.toString()+
                ", referee3=" + referee3.toString()+
                ", stadium=" + stadium.toString()+
                '}';
    }
}
