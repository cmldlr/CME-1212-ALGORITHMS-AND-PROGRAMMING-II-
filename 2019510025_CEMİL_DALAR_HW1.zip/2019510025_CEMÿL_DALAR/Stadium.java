

public class Stadium {
    private String name;
    private String city;
    private int capacity;
    private boolean lighting;
    private String surface;
    private int statidum_id;

    public Stadium(String name,String city,int capacity,boolean lighting,String surface,int statidum_id) {
        this.name=name;
        this.city=city;
        this.capacity=capacity;
        this.lighting=lighting;
        this.surface=surface;
        this.statidum_id=statidum_id;
    }

    public Stadium() {

    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public int getCapacity() {
        return capacity;
    }

    public void setCapacity(int capacity) {
        this.capacity = capacity;
    }

    public boolean isLighting() {
        return lighting;
    }

    public void setLighting(boolean lighting) {
        this.lighting = lighting;
    }

    public String getSurface() {
        return surface;
    }

    public void setSurface(String surface) {
        this.surface = surface;
    }

    public int getStatidum_id() {
        return statidum_id;
    }

    public void setStatidum_id(int statidum_id) {
        this.statidum_id = statidum_id;
    }

    @Override
    public String toString() {
        return "Stadium{" +
                "name='" + name + '\'' +
                ", city='" + city + '\'' +
                ", capacity=" + capacity +
                ", lighting=" + lighting +
                ", surface='" + surface + '\'' +
                ", statidum_id=" + statidum_id +
                '}';
    }
}
