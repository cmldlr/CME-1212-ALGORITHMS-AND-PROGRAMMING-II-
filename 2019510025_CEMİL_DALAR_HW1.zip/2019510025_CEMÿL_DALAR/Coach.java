


public class Coach {
    private String name;
    private Adress adress;
    private Phone phonenumber;
    private Date  startdate;
    private Date enddate;
    private int salary;
    private int coach_id;

    public Coach(String name,Adress adress,Phone phonenumber,Date startdate,Date enddate,int salary,int coach_id){
        this.name = name;
        this.adress=adress;
        this.phonenumber = phonenumber;
        this.coach_id=coach_id;
        if(enddate.getYear()<startdate.getYear()){
            System.out.println("!!!ERROR End date cannot be smaller than start date");
        }
        else{
            if(enddate.getYear()==startdate.getYear()){
                if(enddate.getMonth()<startdate.getMonth()){
                    System.out.println("!!!ERROR End date cannot be smaller than start date");
                }
                else{
                    if(enddate.getMonth()==startdate.getMonth()){
                        if(enddate.getDay()<startdate.getDay()){
                            System.out.println("!!!ERROR End date cannot be smaller than start date");
                        }
                        else{
                            this.startdate = startdate;
                            this.enddate = enddate;
                        }
                    }
                    else{
                        this.startdate = startdate;
                        this.enddate = enddate;
                    }
                }
            }
            else{
                this.startdate = startdate;
                this.enddate = enddate;
            }

        }
        if (salary<0){
            System.out.println("!!!ERROR Salary cannot be negative");
        }
        else{
            this.salary = salary;
        }


    }
    public void setName(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }
    public void setAdress(Adress adress){
        this.adress=adress;
    }

    public Adress getAdress() {
        return adress;
    }

    public void setPhonenumber(Phone phonenumber) {
        this.phonenumber = phonenumber;
    }

    public Phone getPhonenumber() {
        return phonenumber;
    }


    public void setStartdate(Date startdate) {
        this.startdate = startdate;
    }

    public Date getStartdate() {
        return startdate;
    }

    public void setEnddate(Date enddate) {
        this.enddate = enddate;
    }

    public Date getEnddate() {
        return enddate;
    }

    public void setSalary(int salary) {
        this.salary = salary;
    }

    public int getSalary() {
        return salary;
    }

    @Override
    public String toString() {
        return "Coach{" +
                "name='" + name + '\'' +
                ", adress=" + adress.toString()+
                ", phonenumber=" + phonenumber.toString()+
                ", startdate=" + startdate.toString()+
                ", enddate=" + enddate.toString()+
                ", salary=" + salary +
                ", coach_id=" + coach_id +
                '}';
    }
}
