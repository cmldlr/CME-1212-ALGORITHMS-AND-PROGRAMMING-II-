
public class Phone {
    private int countrycode;
    private int areacode;
    private int number;

    public Phone(int countrycode,int areacode,int number){
        this.countrycode = countrycode;
        this.areacode = areacode;
        this.number = number;

    }
    public void setCountrycode(int countrycode) {
        this.countrycode = countrycode;
    }

    public int getCountrycode() {
        return countrycode;
    }

    public void setAreacode(int areacode) {
        this.areacode = areacode;
    }

    public int getAreacode() {
        return areacode;
    }

    public void setNumber(int number) {
        this.number = number;
    }

    public int getNumber() {
        return number;
    }

    @Override
    public String toString() {
        return "Phone{" +
                "countrycode=" + countrycode +
                ", areacode=" + areacode +
                ", number=" + number +
                '}';
    }
}
