

public class Company {
    private String name;
    private Adress adress;
    private Phone phonenumber;
    private int company_id;

    public Company(String name,Adress adress,Phone phonenumber,int company_id){
        this.name=name;
        this.adress=adress;
        this.phonenumber=phonenumber;
        this.company_id=company_id;

    }
    public Adress getAdress() {
        return adress;
    }

    public void setAdress(Adress adress) {
        this.adress = adress;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Phone getPhonenumber() {
        return phonenumber;
    }

    public void setPhonenumber(Phone phonenumber) {
        this.phonenumber = phonenumber;
    }


    public int getCompany_id() {
        return company_id;
    }

    public void setCompany_id(int company_id) {
        this.company_id = company_id;
    }

    @Override
    public String toString() {
        return "Company{" +
                "name='" + name + '\'' +
                ", adress=" + adress.toString()+
                ", phonenumber=" + phonenumber.toString()+
                ", company_id=" + company_id +
                '}';
    }
}
