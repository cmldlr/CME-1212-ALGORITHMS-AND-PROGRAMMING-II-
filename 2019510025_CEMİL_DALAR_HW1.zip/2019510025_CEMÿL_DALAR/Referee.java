

public class Referee {
    private String name;
    private  Adress adress;
    private  Phone phonenumber;
    private  int referee_id;
    private  int salary;
    public void addRaise(int raise_rate){
        raisesalary raisesalary=new raisesalary();
        this.salary=raisesalary.addRaise1(raise_rate);


    }
    public class raisesalary{
       public int salary=Referee.this.getSalary();
       public int  addRaise1(int raise_rate){
          salary=salary+(salary*raise_rate/100);
          return salary;
       }

        public int getSalary() {
            return salary;
        }

        public void setSalary(int salary) {
            this.salary = salary;
        }
    }
    public Referee(String name,Adress adress,Phone phonenumber,int salary,int  referee_id){
        this.name=name;
        this.adress=adress;
        this.phonenumber=phonenumber;
        this.salary=salary;
        this.referee_id=referee_id;

    }
    public Referee(){

    }

    public Adress getAdress() {
        return adress;
    }

    public void setAdress(Adress adress) {
        this.adress = adress;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Phone getPhonenumber() {
        return phonenumber;
    }

    public void setPhonenumber(Phone phonenumber) {
        this.phonenumber= phonenumber;
    }

    public int getReferee_id() {
        return referee_id;
    }

    public void setReferee_id(int referee_id) {
        this.referee_id = referee_id;
    }

    public int getSalary() {
        return salary;
    }

    public void setSalary(int salary) {
        this.salary = salary;
    }



    @Override
    public String toString() {
        return "Referee{" +
                "name='" + name + '\'' +
                ", adress=" + adress.toString()+
                ", phonenumber=" + phonenumber.toString()+
                ", referee_id=" + referee_id +
                ", salary=" + salary +
                '}';
    }
}
