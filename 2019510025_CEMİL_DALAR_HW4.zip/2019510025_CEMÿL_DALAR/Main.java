
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Locale;
import java.util.Random;

public class Main {
    public static Random rnd=new Random();
    public static int user_score=0;
    public static int SSL5_count=0;
    public static void playingthegame(SSL SSL2,SSL SSL4,SSL SSL5,SSL wheel){
        for (int i = 0; i <50; i++) {
            int b=rnd.nextInt(wheel.size());
            Node price= wheel.search(b);
            printthegame(SSL2,SSL5,i);
            if(String.valueOf(price.getData()).equalsIgnoreCase("Bankrupt")){
                System.out.print("Whell:"+price.getData());
                System.out.println();
                System.out.println("It's bankrupt so you can't guess letters. And your score will be 0. ");
                user_score=0;
            }else{
                System.out.print("Whell:"+price.getData());
                int a= rnd.nextInt(SSL2.size());
                Node letter=SSL2.search(a);
                SSL2.delete(letter.getData());
                System.out.println(" ");
                System.out.print("Guess:"+letter.getData()+" ");
                System.out.println(" ");
                if(SSL4.search(letter.getData())){

                    findtheletters(letter.getData(),SSL4,SSL5,price);
                }
                else{
                    findtheletters(letter.getData(),SSL4,SSL5,price);
                }
            }
            if (SSL5_count== SSL5.size()){
                printthegame(SSL2,SSL5,i+1);
                break;
            }

        }
        System.out.println("You get "+user_score+" TL !!!");

    }
    public static void findtheletters(Object letter,SSL SSL4,SSL SSL5,Node price){
        Node head=SSL4.getHead();
        Node head1=SSL5.getHead();
        int count=0;
        if (head == null)
            System.out.println("linked list is empty");
        else {
            if(head!=null){
                Node temp = head;
                Node temp1=head1;
                while (temp != null) {
                    if(String.valueOf(temp.getData()).equalsIgnoreCase(String.valueOf(letter))){
                        temp.setData(" ");
                        temp1.setData(letter);
                        count++;
                        SSL5_count++;
                    }
                    temp = temp.getLink();
                    temp1=temp1.getLink();

                }

            }

        }
        if(String.valueOf(price.getData()).equalsIgnoreCase("Bankrupt")){
            user_score=0;
        }
        else{
            user_score=user_score+count*(int)price.getData();
        }

    }
    public static void printthegame(SSL SSL2,SSL SSL5,int i){

        Node head1=SSL5.getHead();
        Node temp1=head1;

        System.out.print("Word: ");
        while (temp1!= null) {
            if(String.valueOf(temp1.getData()).equalsIgnoreCase(" ")){
                System.out.print("_"+" ");
            }
            else{
                System.out.print(temp1.getData()+" ");
            }
            temp1=temp1.getLink();

        }
        System.out.print("                       "+"STEP:"+(i+1)+"          Score: "+user_score+"          "+SSL2.print());
        System.out.println(" ");



    }
    public static void main(String[] args) throws IOException {
        BufferedReader br=new BufferedReader(new FileReader("D:\\animals.txt"));
        String str="";
        SSL SSL1=new SSL();
        while ((str=br.readLine())!=null){
             SSL1.addString(str.toUpperCase(Locale.ENGLISH));
        }
        SSL SSL2=new SSL();
        String str1="a b c d e f g h i j k l m n o p q r s t u v w x y z";
        String [] letters=str1.split(" ");
        for (int i = 0; i <letters.length; i++) {
            SSL2.addString(letters[i].toUpperCase(Locale.ENGLISH));
        }
        SSL SSL4=new SSL();
        int a=rnd.nextInt(SSL1.size());
        System.out.println("Randomly generated number: "+a);
        Node n1=SSL1.search(a);
        String str2=String.valueOf(n1.getData());
        for (int i = 0; i <str2.length(); i++) {
           SSL4.unordered_addition(str2.charAt(i));
        }
        SSL SSL5=new SSL();
        for (int i = 0; i <SSL4.size(); i++) {
            SSL5.unordered_addition(" ");
        }
        SSL wheel=new SSL();
        wheel.unordered_addition(10);
        wheel.unordered_addition(20);
        wheel.unordered_addition(30);
        wheel.unordered_addition(40);
        wheel.unordered_addition(100);
        wheel.unordered_addition(200);
        wheel.unordered_addition(300);
        wheel.unordered_addition(400);
        wheel.unordered_addition("Bankrupt");
        wheel.unordered_addition("Bankrupt");
        playingthegame(SSL2,SSL4,SSL5,wheel);
        BufferedReader br1=new BufferedReader(new FileReader("HighScoreTable.txt"));
        String str3=" ";
        String user_name="you";
        /*SSL SSL3=new SSL();
        int count=0;
        Node person=new Node(null,0);
        while ((str3=br1.readLine())!=null){
            if(count%2==0){
                person.setName(str3);
                System.out.println(person.getName());
                SSL3.unordered_addition(str3);
            }
            else{
                int b=Integer.parseInt(str3);
                person.setScore(b);
                System.out.println(person.getName()+person.getScore());
                System.out.println(person.getData());
                SSL3.unordered_addition(str3);
                SSL3.add(b);
            }
            count++;

        }
        System.out.println(SSL3.print());*/




    }
}
