

import java.io.*;
import java.util.Random;

public class Main {
    public static  Random rnd=new Random();
    //print step
    public static void printsteps(Stack s1,Stack s2){
        Stack temp_s1=new Stack(s1.size());
        Stack copied_s1=new Stack(s1.size());
        Stack temp_s2=new Stack(s2.size());
        Stack copied_s2=new Stack(s2.size());
        System.out.println(" ");
        System.out.print("Stack1:");
        while(!s1.isEmpty()){

            temp_s1.push(s1.peek());
            copied_s1.push(s1.peek());
            s1.pop();
        }
        while(!temp_s1.isEmpty()){
            System.out.print(temp_s1.peek()+" ");
            s1.push(temp_s1.peek());
            temp_s1.pop();
        }
        System.out.println(" ");
        System.out.print("Stack2:");

        while (!s2.isEmpty()){

            temp_s2.push(s2.peek());
            copied_s2.push(s2.peek());
            s2.pop();
        }
        while(!temp_s2.isEmpty()){
            System.out.print(temp_s2.peek()+" ");
            s2.push(temp_s2.peek());
            temp_s2.pop();
        }
        System.out.println();
    }

    //play the game
    public static int playgame(Stack fruitstack,Stack s1,Stack s2){
        Stack temp_s1=new Stack(s1.size());
        Stack copied_s1=new Stack(s1.size());
        Stack temp_s2=new Stack(s2.size());
        Stack copied_s2=new Stack(s2.size());
        Stack temp_fruitstack=new Stack(fruitstack.size());
        System.out.print("Fruit Stack:");

        while (!fruitstack.isEmpty()){
            System.out.print(fruitstack.peek()+" ");
            temp_fruitstack.push(fruitstack.peek());

            fruitstack.pop();
        }
        System.out.println();
        while(!temp_fruitstack.isEmpty()){
            fruitstack.push(temp_fruitstack.peek());
            temp_fruitstack.pop();
        }
        System.out.println();
        System.out.print("Stack1:");
        while(!s1.isEmpty()){

            temp_s1.push(s1.peek());
            copied_s1.push(s1.peek());
            s1.pop();
        }
        while(!temp_s1.isEmpty()){
            System.out.print(temp_s1.peek()+" ");
            s1.push(temp_s1.peek());
            temp_s1.pop();
        }
        System.out.println();
        System.out.print("Stack2:");
        while (!s2.isEmpty()){

            temp_s2.push(s2.peek());
            copied_s2.push(s2.peek());
            s2.pop();
        }
        while(!temp_s2.isEmpty()){
            System.out.print(temp_s2.peek()+" ");
            s2.push(temp_s2.peek());
            temp_s2.pop();
        }
        System.out.println();
        int score=0;
        for (int i = 0; i <200; i++) {
            System.out.println("                                                     Score="+score);
            if(s1.size()!=0 && s2.size()!=0){
                int a=rnd.nextInt(s1.size())+1;
                int b=rnd.nextInt(s2.size())+1;
                System.out.println("Randomly generated numbers: "+a+"  "+b+"       Step="+(i+1));
                String obje1="";
                String obje2="";
                while (!s1.isEmpty()){
                    if(s1.size()==a){
                        obje1=(String) s1.peek();
                        temp_s1.push(s1.peek());
                        s1.pop();
                    }
                    else{
                        temp_s1.push(s1.peek());
                        s1.pop();
                    }
                }
                while(!temp_s1.isEmpty()){
                    s1.push(temp_s1.peek());
                    temp_s1.pop();

                }
                while (!s2.isEmpty()){
                    if(s2.size()==b){
                        obje2=(String) s2.peek();
                        temp_s2.push(s2.peek());
                        s2.pop();
                    }
                    else{
                        temp_s2.push(s2.peek());
                        s2.pop();
                    }
                }
                while (!temp_s2.isEmpty()){
                    s2.push(temp_s2.peek());
                    temp_s2.pop();
                }
                if(obje1.equalsIgnoreCase(obje2)!=true){
                    printsteps(s1,s2);
                    score=score-1;

                }
                else{
                    while(!s1.isEmpty()){
                        String obje3=(String)s1.peek();
                        if(obje1.equalsIgnoreCase(obje3)){
                            s1.pop();

                        }
                        else{
                            temp_s1.push(s1.peek());
                            s1.pop();
                        }
                    }
                    while (!temp_s1.isEmpty()){
                        s1.push(temp_s1.peek());
                        temp_s1.pop();
                    }
                    while(!s2.isEmpty()){
                        String obje4=(String)s2.peek();
                        if(obje2.equalsIgnoreCase(obje4)){
                            s2.pop();

                        }
                        else{
                            temp_s2.push(s2.peek());
                            s2.pop();
                        }
                    }
                    while (!temp_s2.isEmpty()){
                        s2.push(temp_s2.peek());
                        temp_s2.pop();
                    }
                    printsteps(s1,s2);
                    score=score+20;
                }
            }
            else{
                System.out.println("The game is over.");
                break;
            }





        }
        return score;
    }
    //sorted highscorestack
    public static Stack sortStack(Stack highscorestack) {
        if (highscorestack == null)
            return null;
        if (highscorestack.size() < 2)
            return highscorestack;

        Stack result = new Stack(highscorestack.size());
        while (!highscorestack.isEmpty()) {

            String a=String.valueOf(highscorestack.pop());
            int smallest = Integer.parseInt(a);
            Object obje1=highscorestack.pop();
            int remainder = highscorestack.size();
            for (int i = 0; i < remainder; i++) {
                String b=String.valueOf(highscorestack.pop());
                int element = Integer.parseInt(b);
                Object obje2=highscorestack.pop();
                if (element < smallest) {
                    highscorestack.push(obje1);
                    highscorestack.push(smallest);
                    smallest = element;
                    obje1=obje2;
                } else {
                    highscorestack.push(obje2);
                    highscorestack.push(element);





                }
            }
            result.push(smallest);
            result.push(obje1);




        }
        return result;
    }

        public static void main(String[] args) throws IOException {

        BufferedReader br=new BufferedReader(new FileReader("D:\\fruits.txt"));
        BufferedReader br1=new BufferedReader(new FileReader("D:\\highscoretable.txt"));
        String str="";
        String str1="";
        Stack fruitstack=new Stack(15);
        Stack tempfruitstack=new Stack(15);
        Stack copyfruitstack=new Stack(15);
        Stack hıghscoretablestack=new Stack(50);
        Stack temp_hıghscoretablestack=new Stack(50);
        while((str=br.readLine())!=null){
           fruitstack.push(str);
        }

        while (!fruitstack.isEmpty()){
            tempfruitstack.push(fruitstack.peek());
            copyfruitstack.push(fruitstack.peek());
            fruitstack.pop();
        }
        while (!tempfruitstack.isEmpty()){
            fruitstack.push(tempfruitstack.peek());
            tempfruitstack.pop();
        }
        int x=5;
        Stack s1=new Stack(x);
        Stack s2=new Stack(x);
        Stack temp_s1=new Stack(x);
        Stack copied_s1=new Stack(x);
        int count=0;
        //random stack from fruitstack
        for (int i = 0; i < 20; i++) {
            int random_fruit_index= rnd.nextInt(fruitstack.size());
            while(!fruitstack.isEmpty()){
                if(fruitstack.size()==random_fruit_index){
                       s1.push(fruitstack.peek());;
                       fruitstack.pop();
                       count++;
                }
                else{
                    tempfruitstack.push(fruitstack.peek());
                    fruitstack.pop();
                }
            }
            while (!tempfruitstack.isEmpty()){
                fruitstack.push(tempfruitstack.peek());
                tempfruitstack.pop();
            }
            if(count==x){
                break;
            }
        }
        while (!fruitstack.isEmpty()){
            fruitstack.pop();
        }
        while (!copyfruitstack.isEmpty()){
            fruitstack.push(copyfruitstack.peek());
            copyfruitstack.pop();
        }
        while (!s1.isEmpty()){
            temp_s1.push(s1.peek());
            copied_s1.push(s1.peek());
            s1.pop();
        }
        while (!temp_s1.isEmpty()) {
            s1.push(temp_s1.peek());
            temp_s1.pop();

        }
        //random stack from s1 stack
        for (int i = 0; i <x; i++) {
            int random_s1_index= rnd.nextInt(s1.size());
            while(!s1.isEmpty()){
                if(s1.size()-1==random_s1_index){
                    s2.push(s1.peek());
                    s1.pop();
                }
                else{
                    temp_s1.push(s1.peek());
                    s1.pop();
                }
            }
            while(!temp_s1.isEmpty()){
                s1.push(temp_s1.peek());
                temp_s1.pop();
            }
        }
        while(!copied_s1.isEmpty()){
            s1.push(copied_s1.peek());
            copied_s1.pop();
        }
        String user_name="You";
        int user_score=playgame(fruitstack,s1,s2);

        while ((str1= br1.readLine())!=null){
              hıghscoretablestack.push(str1);
        }
        int min=9999;
        int count1=0;
        //finding min score
        while (!hıghscoretablestack.isEmpty()){
            temp_hıghscoretablestack.push(hıghscoretablestack.peek());
            count1++;
            if(count1%2==1){
                String a=(String)hıghscoretablestack.peek();
                int b=Integer.parseInt(a);
                if(min>b){
                    min=b;
                }
            }
            hıghscoretablestack.pop();
        }
        while (!temp_hıghscoretablestack.isEmpty()){
            hıghscoretablestack.push(temp_hıghscoretablestack.pop());
        }
        //adding user score in highscorestack
        if(min>user_score){
            hıghscoretablestack=sortStack(hıghscoretablestack);
        }

        else if(min==user_score){
            hıghscoretablestack.push(user_name);
            hıghscoretablestack.push(user_score);
            hıghscoretablestack=sortStack(hıghscoretablestack);
        }
        else{
            while (!hıghscoretablestack.isEmpty()){
                String a=String.valueOf(min);
                String b=String.valueOf(hıghscoretablestack.peek());
                if(a.equalsIgnoreCase(b)){
                    hıghscoretablestack.pop();
                    hıghscoretablestack.pop();
                    hıghscoretablestack.push(user_name);
                    hıghscoretablestack.push(user_score);

                }
                else{
                    temp_hıghscoretablestack.push(hıghscoretablestack.pop());
                }
            }
            while (!temp_hıghscoretablestack.isEmpty()){
                hıghscoretablestack.push(temp_hıghscoretablestack.peek());
                temp_hıghscoretablestack.pop();
            }
            hıghscoretablestack=sortStack(hıghscoretablestack);
        }

        int count4=0;
        while (!hıghscoretablestack.isEmpty()){
            temp_hıghscoretablestack.push(hıghscoretablestack.peek());
            System.out.print(hıghscoretablestack.peek()+" ");
            count4++;
            hıghscoretablestack.pop();
            if(count4%2==0){
                System.out.println();
            }
        }
        while (!temp_hıghscoretablestack.isEmpty()) {
            hıghscoretablestack.push(temp_hıghscoretablestack.pop());
        }
        try {
            BufferedWriter bw= new BufferedWriter(new FileWriter("D:\\highscoretable.txt"));
            while (!hıghscoretablestack.isEmpty()){
                    String str2=String.valueOf(hıghscoretablestack.peek());
                    bw.write(str2+"\n");
                    temp_hıghscoretablestack.push(hıghscoretablestack.peek());
                    hıghscoretablestack.pop();
            }
            bw.close();
        }catch (IOException e){
            e.printStackTrace();
        }
        while (!temp_hıghscoretablestack.isEmpty()){
             hıghscoretablestack.push(temp_hıghscoretablestack.pop());
        }








    }
}
